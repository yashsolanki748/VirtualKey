package com.yash;

import java.io.*;
import java.util.Scanner;

public class Main {

    static void FileRetrieval() {

        try {
            File ob = new File("C:\\Users\\yash\\VirtualKeyProject");
            File array[] = ob.listFiles();

            for (int i = 0; i < array.length; i++) {
                System.out.println(array[i]);
            }
        } catch (SecurityException e) {
            System.out.println("Access denied");
        }
    }

    static void FileAddition() {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        try {
            File file = new File(name);
            file.createNewFile();
        } catch (SecurityException e) {
            System.out.println("Access denied");
        } catch (IOException e) {
            System.out.println("IOException");
        }

    }

    static void FileDeletion() {
        Scanner sc1 = new Scanner(System.in);
        String name = sc1.nextLine();
        try {
            File file = new File(name);
            if (file.exists()) {
                file.delete();
                System.out.println("File deleted successfully");
            } else {
                System.out.println("File not found");
            }
        } catch (SecurityException e) {
            System.out.println("Access denied");
        }
    }

    static void FileSearch() {
        Scanner sc2 = new Scanner(System.in);
        String name2 = sc2.nextLine();
        try {
            File ob = new File("C:\\Users\\yash\\VirtualKeyProject");
            File array[] = ob.listFiles();
            boolean isFileFound = false;

            for (int i = 0; i < array.length; i++) {
                if (array[i].getName().startsWith(name2)) {
                    isFileFound = true;
                    System.out.println(array[i]);
                }
            }
            if (!isFileFound) {
                System.out.println("File not found");
            }
        } catch (SecurityException e) {
            System.out.println("Access denied");
        }


    }

    public static void main(String[] args) {

        File folder = new File("C:\\Users\\yash\\VirtualKeyProject");
        if (folder.exists()) {
            System.out.println();
        } else {
            folder.mkdir();
        }


        System.out.println("Welcome to the LockedMe App\n" + "---------------------------");
        System.out.println("Developed by Yash Solanki\n" + "---------------------------");


        while (true) {
            System.out.println("Select one of the following options:\n" + "---------------------------");
            System.out.println("Press 1: Display all files in the Root Directory");
            System.out.println("Press 2: File Operations");
            System.out.println("Press 3: Exit");

            Scanner scan = new Scanner(System.in);
            int choice = scan.nextInt();

            switch (choice) {
                case 1:
                    FileRetrieval();
                    break;
                case 2:
                    boolean isBreakLoop = false;
                    while (true) {
                        System.out.println("Press 1: Add a file/folder to directory");
                        System.out.println("Press 2: Delete a file/folder");
                        System.out.println("Press 3: Search any file/folder by name");
                        System.out.println("Press 4: Return to previous menu");
                        System.out.println("Press 5: Exit");

                        int choice_2 = scan.nextInt();

                        switch (choice_2) {
                            case 1:
                                System.out.println("Enter the name of the file");
                                FileAddition();
                                System.out.println("File added successfully");
                                break;

                            case 2:
                                System.out.println("Enter the name of the file/folder to delete");
                                FileDeletion();
                                break;

                            case 3:
                                System.out.println("Enter the initials of required file");
                                FileSearch();
                                break;

                            case 4:
                                isBreakLoop = true;
                                break;

                            case 5:
                                System.out.println("Program terminated successfully\n" + "---------------------------");
                                System.exit(0);
                                break;

                            default:
                                System.out.println("Please enter the correct choice");
                        }
                        if (isBreakLoop) {
                            isBreakLoop = false;
                            break;
                        }
                    }
                    break;
                case 3:
                    System.out.println("Program terminated successfully\n" + "---------------------------");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Please enter the correct choice");
            }
        }
    }
}